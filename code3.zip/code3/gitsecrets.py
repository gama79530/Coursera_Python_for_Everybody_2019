# Keep this file separate

# https://github.com/settings/applications
# Create new App and get the two strings
# Do not check thes in or reveal them to anyone

def secrets():
    return {"client_id": "6a0...e5e",
            "client_secret": "29e...1c8"}
